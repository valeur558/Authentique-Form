
CREATE DATABASE authentique_formation;
USE authentique_formation;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prenom VARCHAR(50),
    nom VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
);
