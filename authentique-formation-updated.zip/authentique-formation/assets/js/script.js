
document.querySelector("form").onsubmit = function(event) {
    let email = document.querySelector("#email").value;
    if (!email.includes("@")) {
        alert("Veuillez entrer un email valide.");
        event.preventDefault();
    }
};
