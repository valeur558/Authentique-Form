
<footer>
    <p>&copy; 2024 Authentique Formation. Tous droits réservés.</p>
</footer>
</body>
</html>
