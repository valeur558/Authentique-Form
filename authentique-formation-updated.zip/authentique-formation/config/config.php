
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "authentique_formation";
?>
