
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "authentique_formation";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Cet e-mail est déjà utilisé.";
    } else {
        $sql = "INSERT INTO users (prenom, nom, email, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $prenom, $nom, $email, $password);
        if ($stmt->execute()) {
            echo "Inscription réussie !";
            header("Location: connexion.html");
            exit();
        } else {
            echo "Erreur lors de l'inscription: " . $conn->error;
        }
    }
    $conn->close();
}
?>
