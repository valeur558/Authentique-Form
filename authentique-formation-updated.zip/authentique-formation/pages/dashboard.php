
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.html");
    exit();
}
?>
<?php include('includes/header.php'); ?>
<h2>Bienvenue, <?php echo $_SESSION['user_name']; ?></h2>
<p>Votre tableau de bord.</p>
<a href="forms/logout.php">Se déconnecter</a>
<?php include('includes/footer.php'); ?>
